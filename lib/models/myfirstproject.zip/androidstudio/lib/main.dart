//import 'package:androidstudio/home_screen.dart';
import 'package:androidstudio/modules/bmi_calc/BMI_RESULT.dart';
import 'package:androidstudio/modules/bmi/Bmi_Calculator.dart';
import 'package:androidstudio/modules/counter/Counter_Screen.dart';
import 'package:androidstudio/modules/messenger/Messenger_screen.dart';
import 'package:androidstudio/modules/login/login_gate.dart';
import 'package:flutter/material.dart';

import 'modules/users/users_screens.dart';

void main() {
  runApp(MyApp());

}

class MyApp extends StatelessWidget
{
  @override
  Widget build(BuildContext context)
  {

    return MaterialApp(
      debugShowCheckedModeBanner: false,
     home: login_gate(),

 );
  }



}