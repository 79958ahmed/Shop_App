import 'package:flutter/material.dart';

class Counter_Screen extends  StatefulWidget {

  @override
  State<Counter_Screen> createState() => _Counter_ScreenState();
}

class _Counter_ScreenState extends State<Counter_Screen> {
int counter=1;
@override
  void initState() {
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Counter'
        ),
      ),
body: Center(
  child:   Row(

    mainAxisAlignment: MainAxisAlignment.center,

    children: [

      TextButton(
        onPressed:(){
          setState(() {
            counter--;
            print (counter);
          });
        } ,
          child:Text(
            'minus',
            style: TextStyle(
              fontSize: 40,
              fontWeight: FontWeight.w100,
            ),
          ),
      ),
      Padding(
        padding: const EdgeInsets.all(20.0),
        child: Text(
          '$counter',
          style: TextStyle(
            fontSize: 80,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      TextButton(onPressed:(){
        setState(() {
          counter++;
          print (counter);
        });
      } ,
        child:Text(
          'plus',
          style: TextStyle(
            fontSize: 40,
            fontWeight: FontWeight.w100,
          ),
        ),
      ),
    ],
  ),
),
    );
  }
}
