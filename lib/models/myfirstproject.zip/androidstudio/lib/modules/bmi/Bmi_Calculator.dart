
import 'dart:math';

import 'package:androidstudio/modules/bmi_calc/BMI_RESULT.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Bmi_Calculator extends StatefulWidget {

  @override
  State<Bmi_Calculator> createState() => _Bmi_CalculatorState();
}

class _Bmi_CalculatorState extends State<Bmi_Calculator> {
bool isMale =true;
double height =120.0;
int weight=50;
int age=20;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'BMI calculator',
        ),

      ),
body: Column(
  children: [
    Expanded(
      child: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Row(
         children: [
           Expanded(
             child: GestureDetector(
onTap: (){
 setState(() {
   isMale =true;
 });

},
               child: Container(

                 child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                   children: [
                     Image(
                       image:AssetImage('images/male.png') ,
height: 90,
                       width: 90,
                     ),
                     SizedBox(
                       width: 20,

                     ),

                     Text(
                       'Male',
                       style: TextStyle(
                         fontSize: 30,
                         fontWeight: FontWeight.bold,
                       ),

                     ),
                   ],
                 ),
                 decoration:BoxDecoration(

                   borderRadius: BorderRadius.circular(10),
                   color:isMale ?Colors.red : Colors.blue ,
                 ),
               ),
             ),
           ),
           SizedBox(
             width: 15,
           ),
           Expanded(
             child: GestureDetector(
           onTap: (){
    setState(() {
    isMale =false;
    });
    },
               child: Container(

                 child: Column(
                   mainAxisAlignment: MainAxisAlignment.center,
                   children: [
                 Image(
                 image:AssetImage('images/female.png') ,
                 height: 90,
                 width: 90,
               ),
                     SizedBox(
                       width: 20,

                     ),

                     Text(
                       'famale',
                       style: TextStyle(
                         fontSize: 30,
                         fontWeight: FontWeight.bold,
                       ),

                     ),
                   ],
                 ),
                 decoration:BoxDecoration(
                   borderRadius: BorderRadius.circular(10),
                   color:!isMale ?Colors.red : Colors.blue ,
                 ),
               ),
             ),
           ),
         ],
        ),
      ),
    ),
    Expanded(
    child: Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 20,
      ),
      child: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
        children :[
        Text(
        'HEIGHT',
        style: TextStyle(
        fontSize: 30,
        fontWeight: FontWeight.bold,
        ),
        ),
Row(
  crossAxisAlignment: CrossAxisAlignment.baseline,
  mainAxisAlignment: MainAxisAlignment.center,
  textBaseline: TextBaseline.alphabetic,
  children: [
        Text(
        '${height.round()}',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 40,

          ),
        ),
        SizedBox(
          width: 5,
        ),
        Text(
          'cm',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,

          ),
        ),


  ],
),
          Slider(value:height ,
            max:225 ,
            min: 80,
            onChanged: (value){
            setState(() {
              height=value;
            });
              print(value.round());
            },
          ),
        ],

          ),
        decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        color: Colors.yellow,
        ),
      ),
    ),
    ),
    Expanded(
    child:Padding(
      padding: const EdgeInsets.all(20.0),
      child: Row(
        children: [
        Expanded(
          child: Container(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
children: [
  Text(
      'WEIGHT',
      style: TextStyle(
            fontSize: 30,
            fontWeight: FontWeight.bold,
      ),
  ),
  Text(
  '$weight',
  style: TextStyle(
      fontWeight: FontWeight.bold,
      fontSize: 40,

      ),
      ),
      Row(
        mainAxisAlignment: MainAxisAlignment.center,
      children: [
            FloatingActionButton(

      onPressed:(){
        setState(() {
       weight--;
        });

      },
              heroTag:'weight' ,
              mini: true,
      child: Icon(
      Icons.remove,
      ),

      ),
            FloatingActionButton(
              onPressed:(){
                setState(() {
                  weight++;

                });
              },
              mini: true,
              child: Icon(
                Icons.add,
              ),
heroTag: 'wight +',
            ),


            ],
  ),


],
            ),
            decoration:BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Colors.blue,
            ),
          ),
        ) ,
          SizedBox(
            width: 20,
          ),
          Expanded(
            child: Container(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'AGE',
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    '$age',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 40,

                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      FloatingActionButton(
                        onPressed:(){
                          setState(() {
                            age--;
                          });

                        },
                        heroTag: 'age-',
                        mini: true,
                        child: Icon(
                          Icons.remove,
                        ),

                      ),
                      FloatingActionButton(
                        onPressed:(){
                          setState(() {
                            age++;
                          });
                        },
                        heroTag: 'age+',

                        mini: true,
                        child: Icon(
                          Icons.add,
                        ),

                      ),


                    ],
                  ),


                ],
              ),
              decoration:BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.blue,
              ),
            ),
          ) ,


        ],

      ),
    ),
    ),
    Container(
      width: double.infinity,
      color: Colors.red,
      child: MaterialButton(
        onPressed:(){
          double result =weight /pow(height/100,2);
          print (result.round());
          
          Navigator.push(
            context,
            MaterialPageRoute(
              builder:(context)=>BMI_RESULT(isMale: isMale,
                  result: result.round(),
                  age: age
              ),

          ),
          );
      },
        height: 60,
      child: Text(
        'CALCULATE',
        style: TextStyle(
          color: Colors.white,
        ),
      ),
      ),
    ),


  ],



),
    );
  }
}
