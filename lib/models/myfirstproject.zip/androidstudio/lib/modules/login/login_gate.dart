// import 'package:flutter/material.dart';
//
// import '../../shared/components/components.dart';
//
// class login_gate  extends StatelessWidget {
// var emailController=TextEditingController();
// var passwordController=TextEditingController();
// var formKey=GlobalKey<FormState>();
//
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//         appBar:AppBar (),
// body: Padding(
//   padding: const EdgeInsets.all(20.0),
//   child:   SingleChildScrollView(
//     child: Form(
//       key:formKey ,
//       child: Column(
//         crossAxisAlignment: CrossAxisAlignment.start,
//     //    mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           Text(
//             'Login bro',
//             style: TextStyle(
//               fontSize: 45,
//               fontWeight: FontWeight.bold,
//               color: Colors.blueAccent,
//             )
//           ),
//           SizedBox(
//       height: 40.0,
// ),
//
//           SizedBox(
//             height: 15.0,
//           ),
//
//           TextFormField(
//             controller: passwordController,
//             obscureText: true,
//               keyboardType: TextInputType.visiblePassword ,
//               onFieldSubmitted:(value)
//               {
//                 print(value);
//               },
//               onChanged: (value){
//                 print(value);
//               },
//               validator: ( value){
//                 if(value.isEmpty)
//                 {
//                   return'password must not be empty';
//                 }
//                 return null;
//               },
//               decoration:InputDecoration (
//
//                 labelText: 'password',
//                 prefixIcon: Icon(
//                   Icons.lock,
//                 ),
//                 suffixIcon: Icon(
//                   Icons.remove_red_eye_rounded
//                 ),
//                 border: OutlineInputBorder(),
//               )
//           ),
//           SizedBox(
//             height: 15.0,
//           ),
//           defaultButton(
//         text:'login',
//         background:Colors.blue,
// function:(){
//           if (formKey.currentState.validate()) {
//             print(emailController.text);
//             print(passwordController.text);
//           }
//   },
//            // width:double.infinity,
//           ),
//           SizedBox(
//             height: 15.0,
//           ),
//           defaultButton(
//             text:'gKgin',
//             background:Colors.blue,
//             function:(){
//               print(emailController.text)  ;
//               print(passwordController.text);
//             },
//            isUpperCase: false,
//             width:double.infinity,
//           ),
//
//           SizedBox(
//             height: 10.0,
//           ),
//  Row(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: [
//         Text(
//           'Don\'t have an account?',
//         ),
//         TextButton(
//
//         onPressed: (){},
//           child:Text(
//             'Register now',
//           ),
//
//
//
// ),
//       ],
//
// ),
//
//         ],
//
//       ),
//     ),
//   ),
// ),
//
//     );
//
//
//   }
// }
import 'package:flutter/material.dart';

import '../../shared/components/components.dart';

var emailController = TextEditingController();
var passwordController = TextEditingController();
var formKey = GlobalKey<FormState>();
bool isPasswordShow=true;

class login_screen extends StatefulWidget {
  @override
  State<login_screen> createState() => _login_screenState();
}

class _login_screenState extends State<login_screen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(
            children: [
              Stack(
                alignment: AlignmentDirectional.center,
                children: [
                  Image(
                    image: NetworkImage(
                        'https://images.pexels.com/photos/3695799/pexels-photo-3695799.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500'
                    ),
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                  Padding(
                    padding: const EdgeInsetsDirectional.only(
                      end: 30,
                      start: 30,
                    ),
                    child: Form(
                      key: formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'LOGIN',
                            style: TextStyle(
                              fontSize: 25,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(
                            height: 20.0,
                          ),
                          defaultFormField(
                            perfix: Icons.email,
                            text: 'Email Address',
                            controller: emailController,
                            radius: 20,
                            text1: 'Error',
                            type: TextInputType.emailAddress,
                            onSubmit: (String value) {
                              print(value);
                            },
                          ),
                          SizedBox(
                            height: 20.0,
                          ),
                          defaultFormField(
                            suffixIcon: (){
                              setState(() {
                                isPasswordShow=!isPasswordShow;
                              });
                            },
                            Suffix: isPasswordShow?Icons.visibility_outlined:Icons.visibility_off_outlined,
                            isPassword: isPasswordShow,
                            perfix: Icons.lock,
                            text: 'password',
                            controller: passwordController,
                            radius: 20,
                            text1: 'Error',
                            type: TextInputType.number,
                            onSubmit: (String value) {
                              print(value);
                            },
                          ),
                          SizedBox(
                            height: 15.0,
                          ),
                          defaultButton(
                            background: Colors.white12,
                            function: () {
                              if (formKey.currentState.validate()) {
                                print(emailController.text);
                                print(passwordController.text);
                              }
                            },
                            text: 'login',
                            width: double.infinity,
                          ),
                          SizedBox(
                            height: 10.0,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                'Don\'t have an account?',
                                style: TextStyle(
                                  fontSize: 15,
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(
                                width: 20.0,
                              ),
                              TextButton(
                                onPressed: () {},
                                child: Text(
                                  'Register Now',
                                  style: TextStyle(
                                    fontSize: 15,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}