import 'package:androidstudio/models/user/user_model.dart';
import 'package:flutter/material.dart';


class users_screens extends StatelessWidget {
  List<Usermod> users =[
    Usermod(id: 1,
        name: 'ahmaa',
        phone: '01207457447'),
    Usermod(id: 2,
        name: 'yassin',
        phone: '01207457447'),
    Usermod(id: 3,
        name: 'tantawy',
        phone: '01207457447'),
    Usermod(id: 1,
        name: 'ahmaa',
        phone: '01207457447'),
    Usermod(id: 2,
        name: 'yassin',
        phone: '01207457447'),
    Usermod(id: 3,
        name: 'tantawy',
        phone: '01207457447'),
    Usermod(id: 1,
        name: 'ahmaa',
        phone: '01207457447'),
    Usermod(id: 2,
        name: 'yassin',
        phone: '01207457447'),
    Usermod(id: 3,
        name: 'tantawy',
        phone: '01207457447'),

  ];



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar (
      title: Text(
        'users',
      ),
      ),
      body:ListView.separated(
          itemBuilder: (context, index)=>buildUserIcon(users[index]),
          separatorBuilder: (context,index)=>Padding(
            padding: const EdgeInsetsDirectional.only(
            start: 20,
            ),
            child: Container(
              width: double.infinity,
              color: Colors.grey[400],
            ),
          ),
           itemCount: users.length,),
    );
  }

Widget buildUserIcon(Usermod user)=> Padding(
  padding: const EdgeInsets.all(8.0),
  child: Row(
    children: [
      CircleAvatar(
        radius: 25,
        child: (
            Text(
              '${user.id}',
            )
        ),

      ) ,
      SizedBox(
        width: 20,
      ),
      Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '${user.name}',
          ),
          Text(
            '${user.phone}',
            style:TextStyle(

            ),
          ),
        ],
      ),
    ],
  ),
);



}
