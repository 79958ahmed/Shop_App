// import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.cyanAccent,
        leading: Icon(
          Icons.menu,
        ),
        title: Text(
          'first app',
        ),
        actions:
        [
          IconButton(
            icon: Icon(
              Icons.notification_important,
            ),
            onPressed:onNotification,
          ),
         IconButton(
           icon: Text (
             'ahma'

           ),
           onPressed: (){
             print ('hello');
           },
         ),



        ],



      ),
      body: Column(
        children:
          [
            Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadiusDirectional.only(
                  bottomEnd: Radius.circular(
                    20
                  ),
                ),
              ),
              clipBehavior: Clip.antiAliasWithSaveLayer,
              child: Stack(
                alignment: Alignment.bottomCenter,
                children:
                [
        Image(
  image: NetworkImage (
    'https://th.bing.com/th/id/R.4cd8cea0da9cf70be09a508c899e04df?rik=%2bWoDYx87BsMK6w&pid=ImgRaw&r=0',
  ),

fit: BoxFit.cover ,

),
                  Container(
                    width: 100,
                    color: Colors.black.withOpacity(.7),
                    padding: EdgeInsets.symmetric(
    vertical: 10.0,
    horizontal: 0.0,
    ),
                    child: Text(
                      'kotlin',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 20.0,
                        color: Colors.amber,

                      )

                    ),
                  )
              ],
    ),
            ),
    ],


      ),

      );

  }



  void onNotification() {
    print('notificaion clicked');
  }
}