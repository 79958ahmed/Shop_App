import 'package:flutter/material.dart';

class Messenger_screen extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
titleSpacing: 20,
title: Row(
  children: [
    CircleAvatar(
      radius: 15,
      backgroundImage: NetworkImage('https://th.bing.com/th/id/R.4cd8cea0da9cf70be09a508c899e04df?rik=%2bWoDYx87BsMK6w&pid=ImgRaw&r=0'),
    ),
    SizedBox(
      width: 15,
    ),
    Text(
      'Chats',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
          ),
    ),


  ],


),
actions: [
IconButton(icon: CircleAvatar(
  radius: 60,
  backgroundColor: Colors.blue,

  child:   Icon(

  Icons.camera_alt,



  ),
), onPressed: () {  },

),
    IconButton(icon: CircleAvatar(
    radius: 60,
    backgroundColor: Colors.blue,

    child:   Icon(

    Icons.edit,



    ),
    ), onPressed: () {  },
    ),
],

      ),
body: Padding(
  padding: const EdgeInsets.all(20.0),
  child:   SingleChildScrollView(
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(
              5
            ),
            color: Colors.grey[300],
          ),
          child: Padding(
            padding: const EdgeInsets.all(4.0),
            child: Row(
              children: [
                Icon(
                Icons.search,
                ),
                SizedBox(
                  width: 10,
                ),
                Text(
                  'search',
                ),
              ],
            ),
          ),
        ),
        SizedBox(
    height: 20,
),
        Container(
    height: 90,
    child:   ListView.separated(
      shrinkWrap: true,
//physics: NeverScrollableScrollPhysics(),
      scrollDirection: Axis.horizontal,
        itemBuilder:(context,index){
    return  buildStoryItem();
        },
      separatorBuilder: (context,index)=>SizedBox(
        width: 20,
      ),
      itemCount: 8 ,
    ),
),
        SizedBox(
          height: 20,
        ),
        ListView.separated(
          shrinkWrap: true,
            itemBuilder: (context, index) => buildChatItem(),
            separatorBuilder: (context, index) => SizedBox(
              height: 20,
            ),
            itemCount: 15,
        ),
      ],
    ),
  ),
),
    );
  }
Widget buildChatItem() => Row(
  children: [
    Stack(
      alignment: Alignment.bottomRight,
      children:[
        CircleAvatar(
          radius: 25,
          backgroundImage: NetworkImage('https://th.bing.com/th/id/R.4cd8cea0da9cf70be09a508c899e04df?rik=%2bWoDYx87BsMK6w&pid=ImgRaw&r=0'),
        ),
        CircleAvatar(
          radius: 8,
          backgroundColor: Colors.white,
        ),
        CircleAvatar(
          radius: 7,
          backgroundColor: Colors.green,
        ),

      ],

    ),
    SizedBox(
      width: 18,
    ),
    Expanded(
      child:Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'ahmed yassin',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(
            height: 5,
          ),
          Row(
            children: [
              Text(
                'hello ahmed',
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Container(
                  width: 7,
                  height: 7,
                  decoration: BoxDecoration(
                    color: Colors.blue,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
              Text(
                '10:12 pm',
              ),
            ],
          ),

        ],

      ),
    ),
  ],
);
  Widget buildStoryItem()=>  Container(
    width: 60,
    child:   Column(
      children:
      [
        Stack(
          alignment: Alignment.bottomRight,
          children:[
            CircleAvatar(
              radius: 30,
              backgroundImage: NetworkImage('https://th.bing.com/th/id/R.4cd8cea0da9cf70be09a508c899e04df?rik=%2bWoDYx87BsMK6w&pid=ImgRaw&r=0'),
            ),
            CircleAvatar(
              radius: 8,
              backgroundColor: Colors.white,
            ),
            CircleAvatar(
              radius: 7,
              backgroundColor: Colors.green,
            ),
          ],
        ),
        SizedBox(
          height: 5,
        ),
        Text(
          'ahmed yassin uhiuj',
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
        ),











      ],



    ),

  );
}
