import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class BMI_RESULT extends StatelessWidget {
  final bool isMale ;
  final int result;
  final int age;
  BMI_RESULT({
  required this.isMale,
    required this.result,
    required this.age,

  });
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
       title: Text(
          'Bmi result'
        ),
      ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
  'GENDER : ${isMale ?'MALE' :'female'}',
      style: TextStyle(
          fontSize:20,
          fontWeight: FontWeight.w600
      ),
),
              Text(
                'result :$result',
                style: TextStyle(
                    fontSize:20,
                    fontWeight: FontWeight.w600
                ),
              ),
              Text(
                'age : $age',
                style: TextStyle(
                    fontSize:20,
                    fontWeight: FontWeight.w600
                ),
              ),
            ],

          ),
        ),





    );
  }
}
