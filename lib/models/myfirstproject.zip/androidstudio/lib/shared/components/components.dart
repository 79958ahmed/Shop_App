// //import 'package:flutter/cupertino.dart';
// import 'package:flutter/material.dart';
//
// Widget defaultButton({
//   double  width,
//    Color background,
//   bool isUpperCase =true,
//    Function function,
//    String text,
// }) =>
//     Container(
//       width: width,
//
//       child: MaterialButton(
//         onPressed: function,
//         child: Text(
//           isUpperCase? text.toUpperCase():text,
//           style: TextStyle(
//             color: Colors.white,
//           ),
//         ),
//       ),
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(10,),
//         color: background,
//       ),
//     );
import 'package:flutter/material.dart';

Widget defaultButton({
  double width = double.infinity,
  Color background = Colors.blue,
  bool isUpperCase = true,
  @required Function function,
  @required String text,
}) =>
    Container(
      width: width,
      child: MaterialButton(
        onPressed: function,
        child: Text(
          isUpperCase ? text.toUpperCase() : text,
          style: TextStyle(
            fontSize: 18,
            color: Colors.white,
          ),
        ),
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(3.0),
        color: background,
      ),
    );
Widget defaultFormField ({
  @required TextEditingController controller,
  @required double radius,
  @required TextInputType type,
  @required String text,
  @required String text1,
  Function onSubmit,
  Function suffixIcon,
  @required IconData perfix,
  IconData Suffix,
  bool isPassword =false,
})=>TextFormField(

  obscureText: isPassword,
  validator: (values){
    if (values.isEmpty)
    {
      return text1;
    }
    return null;
  },
  onFieldSubmitted:onSubmit,
  controller: controller,
  style: TextStyle(fontSize: 18.0, color: Colors.white),
  keyboardType: type,
  decoration: InputDecoration(
    focusedErrorBorder:OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius),
      borderSide: BorderSide(color: Colors.red),
    ) ,
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius),
      borderSide: BorderSide(color: Colors.white),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius),
      borderSide: BorderSide(color: Colors.white),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(radius),
      borderSide: BorderSide(color: Colors.red),
    ),
    border: OutlineInputBorder(),
    labelText: text,
    labelStyle: TextStyle(
      color: Colors.white,
    ),
    prefixIcon: Icon(
      perfix,
      color: Colors.white,
    ),

    suffixIcon: IconButton(
      color: Colors.white,
      onPressed:suffixIcon ,
      icon:Icon(Suffix) ,
    ),

  ),
);