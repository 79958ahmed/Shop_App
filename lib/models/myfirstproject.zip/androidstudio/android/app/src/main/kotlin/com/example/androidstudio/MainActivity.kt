package com.example.androidstudio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
